/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_408()
{
    return 3351742792U;
}

unsigned getval_210()
{
    return 2425393240U;
}

unsigned addval_113(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_246(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_260()
{
    return 3301085272U;
}

unsigned getval_151()
{
    return 2430103860U;
}

unsigned addval_119(unsigned x)
{
    return x + 2425393240U;
}

unsigned addval_304(unsigned x)
{
    return x + 3347597354U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_243(unsigned x)
{
    return x + 3281043853U;
}

unsigned addval_367(unsigned x)
{
    return x + 3281046185U;
}

void setval_198(unsigned *p)
{
    *p = 3678978441U;
}

unsigned getval_377()
{
    return 3264272009U;
}

unsigned getval_173()
{
    return 3286280520U;
}

void setval_438(unsigned *p)
{
    *p = 3380920705U;
}

unsigned getval_465()
{
    return 3223374505U;
}

unsigned getval_242()
{
    return 3523791529U;
}

void setval_183(unsigned *p)
{
    *p = 3767093372U;
}

void setval_435(unsigned *p)
{
    *p = 3223377537U;
}

void setval_204(unsigned *p)
{
    *p = 2430634440U;
}

unsigned getval_398()
{
    return 3222853257U;
}

unsigned addval_342(unsigned x)
{
    return x + 2425408137U;
}

unsigned addval_394(unsigned x)
{
    return x + 3676881289U;
}

void setval_115(unsigned *p)
{
    *p = 3767093398U;
}

void setval_247(unsigned *p)
{
    *p = 3229928073U;
}

unsigned addval_101(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_276(unsigned x)
{
    return x + 3223901833U;
}

unsigned addval_146(unsigned x)
{
    return x + 3383020169U;
}

void setval_351(unsigned *p)
{
    *p = 3676357001U;
}

unsigned addval_240(unsigned x)
{
    return x + 3525891721U;
}

unsigned addval_428(unsigned x)
{
    return x + 3682915977U;
}

unsigned addval_138(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_206()
{
    return 3529558665U;
}

void setval_178(unsigned *p)
{
    *p = 3223372169U;
}

unsigned getval_343()
{
    return 3676359307U;
}

void setval_326(unsigned *p)
{
    *p = 3281049225U;
}

unsigned getval_120()
{
    return 3247489417U;
}

unsigned getval_440()
{
    return 3285633359U;
}

unsigned getval_338()
{
    return 3249109819U;
}

unsigned addval_423(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_279(unsigned x)
{
    return x + 2430634248U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
